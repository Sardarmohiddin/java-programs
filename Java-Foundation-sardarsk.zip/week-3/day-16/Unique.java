import java.util.*;
class Unique
  {
    public static void main(String args[])
    {
    int a[]={54,45,2,6,5,2,5};
      boolean b[]=new boolean[a.length];
      
      
      
    }
  }