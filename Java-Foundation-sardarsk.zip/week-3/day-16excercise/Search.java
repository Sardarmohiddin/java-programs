import java.util.*;
class Search
  {
public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the size of array");
      int size=sc.nextInt();
      int a[]=new int[size];
      System.out.println("enter the values in array");
      for(int i=0;i<size;i++)
        {
          a[i]=sc.nextInt();
        }
       System.out.println("enter the value ");
      int value=sc.nextInt();
      search(a,size,value);
    }
    public static void search(int a[],int size,int value)
    {
      for(int i=0;i<size;i++)
        {
          if(a[i]==value)
          {
            System.out.println("the index value is"+i);
          }
          else
          {
            System.out.println("the number is not found in array");
            break;
          }
        }
    }
  }
