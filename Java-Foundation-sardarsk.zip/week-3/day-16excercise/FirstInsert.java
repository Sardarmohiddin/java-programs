import java.util.*;
class FirstInsert
  {
public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the size of array");
      int size=sc.nextInt();
      int a[]=new int[size];
      int b[]=new int[a.length+1];
      System.out.println("enter the value that should come in first element");
      int value=sc.nextInt();
      System.out.println("enter the values in array");
      for(int i=0;i<size;i++)
        {
          a[i]=sc.nextInt();
        }
      first(a,b,size,value);
    }
    public static void first(int a[],int b[],int size,int value)
    {
      int i;
      for(i=0;i<a.length+1;i++)
        {
      
          b[i+1]=a[i];
          b[0]=value;
        }
      System.out.println("the new array after insertion is"+b[i]);
    }
  }
  
    