import java.util.Scanner;
class Alphabet
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the string values");
      String s=sc.nextLine();
      int acount=0;
      int dcount=0;
      int scount=0;
      for(int i=0;i<s.length();i++)
        {
          if(((s.charAt(i)>='a')&&(s.charAt(i)<='z'))||((s.charAt(i)>='A')&&(s.charAt(i)<='Z')))
          {
          acount++;
          }
        else if((s.charAt(i)>='0')&&(s.charAt(i)<='9'))
        {
          dcount++;
        }
        else
        {
          scount++;
        }
       }
      System.out.println("alphabets in a String: "+acount);
      System.out.println("Numbers in String: "+dcount);
      System.out.println("Special Characters in String: "+scount);
    }
  }