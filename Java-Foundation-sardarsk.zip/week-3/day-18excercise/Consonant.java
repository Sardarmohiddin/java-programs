import java.util.*;
class Consonant
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the string values");
      String s=sc.nextLine();
      int concount=0;
      int vowcount=0;
      int i;
      for(i=0;i<s.length();i++)
        {
         char ch=s.charAt(i); if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
          {
            vowcount++;
          }
          else
          {
            concount++;
          }
            
        }
      System.out.println("the vowels in a string are "+vowcount);
      System.out.println("the consonants in a string are "+concount);
    }
  }