//to count the words in a string

    import java.util.Scanner;
class Sample
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
     String s=sc.nextLine();
      String str[]=s.split(" ");
      int count=0;
      for(int i=0;i<str.length;i++)
        {
          count++;
        }
      System.out.println(count);
    }
  }

