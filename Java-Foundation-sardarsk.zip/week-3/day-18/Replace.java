class Replace
  {
    public static void main(String args[])
    {
      String s="sardar is fullstack java developer.sardar  works daily 8 hours.";
      String m=s.replace("sardar","mohiddin");
      System.out.println(s);
      System.out.println(m);
    }
  }