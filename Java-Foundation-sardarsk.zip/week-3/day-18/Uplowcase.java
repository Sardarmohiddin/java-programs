class Uplowcase
  {
    public static void main(String args[])
    {
      String s="sardar";
      String m="MOHIDDIN";
      System.out.println(s);
      System.out.println(m);
      System.out.println(s.toUpperCase());
      System.out.println(s.toLowerCase());
    }
  }
  