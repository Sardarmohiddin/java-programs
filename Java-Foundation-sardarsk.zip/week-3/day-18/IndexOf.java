//indexOf()
import java.util.Scanner;
class IndexOf
  {
    public static void main(String args[])
    {
      String s="welcome toe bitlabs come";
      System.out.println(s.indexOf("come",7));
 
    }
  }