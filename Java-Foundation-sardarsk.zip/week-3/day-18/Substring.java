//substring()
import java.util.Scanner;
class Substring
  {
    public static void main(String args[])
    {
      String s="welcome to bitlabs";
      String str=s.substring(3,7);
      String str1=s.substring(11);
      System.out.println(str); //come
       System.out.println(str1); //bitlabs
      
 
    }
  }