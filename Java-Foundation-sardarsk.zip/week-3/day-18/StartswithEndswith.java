class StartswithEndswith
  {
    public static void main(String args[])
    {
      String s="sardar";
      System.out.println(s.startsWith("s"));
      System.out.println(s.startsWith("r"));
      System.out.println(s.endsWith("r"));
      System.out.println(s.endsWith("a"));
    }
  }