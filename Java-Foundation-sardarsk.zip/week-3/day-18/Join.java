//join()
import java.util.Scanner;
class Join
  {
    public static void main(String args[])
    {
      String str=String.join("-","18","05","2023");
      System.out.println(str);
       String str1=String.join("@","abc","bc","bca");
      System.out.println(str1);
 
    }
  }