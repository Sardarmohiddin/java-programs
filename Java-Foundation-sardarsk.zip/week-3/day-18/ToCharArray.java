//toCharArray()
import java.util.Scanner;
class ToCharArray
  {
    public static void main(String args[])
    {
     String s="bitlabs";
      char ch[]=s.toCharArray();
      for(int i=0;i<ch.length;i++)
        {
          System.out.println(ch[i]+" ");
        }
      
 
    }
  }