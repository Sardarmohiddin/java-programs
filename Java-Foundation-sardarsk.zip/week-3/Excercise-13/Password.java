import java.util.*;
class Excercise13
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      do{
      System.out.println("Enter a password");
      int pass=sc.nextInt();
        System.out.println("choose the option");
        char ch=sc.nextInt();
        if(ch==1)
        {
          System.out.println("the password is incorrect.pls give the correct answer")
        }
          else
          {
            System.out.println("the password is correct");
            
          }
