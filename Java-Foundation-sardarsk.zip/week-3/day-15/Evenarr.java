import java.util.*;
class Evenarr
  {
    public static void even(int a[])
  
  {
    public static void main(String args[])
    {
      int a[]=new int[5];
      Scanner sm=new Scanner(System.in);
      for(int i=0;i<=a.length;i++)
        {
          a[i]=sm.nextInt();
        }
      even(a);
    }
  }