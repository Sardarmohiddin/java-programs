///negative count
import java.util.*;
class Negativecount
  {
    public static void neg(int a[])
    {
      int count=0;
      for(int i=0;i<a.length;i++)
        {
          if(a[i]<0)
          {
             count+=1;
          }
        }
      System.out.println("the negative elements count is "+count);
    }
    public static void main(String args[])
    {
      int a[]=new int[6];
      Scanner sc=new Scanner(System.in);
      System.out.println("enter array elements");
      for(int i=0;i<=6;i++)
        {
          a[i]=sc.nextInt();
        }
      neg(a);
    }
  }