// to count the array elements
import java.util.*;
class CountArray
  
    {
      public static void countable(int a[])
        {
        System.out.println("the elements total count is"+a.length);
        }
    
    public static void main(String args[])
    {
      int a[]=new int[5];
    Scanner sc=new Scanner(System.in);
      System.out.println("enter the array elements");
      for(int i=0;i<a.length;i++)
      {
        a[i]=sc.nextInt();
      }
    countable(a);
  }
    }
  