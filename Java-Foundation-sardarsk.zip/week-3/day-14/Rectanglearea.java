import java.util.*;
class Rectanglearea
  {
    public static void arearec(int len,int bre)
    {
      int area=len*bre;
      System.out.println("the area of a rectangele is "+area);
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("the length is :");
      int a=sc.nextInt();
      System.out.println("the breadth is :");
      int b=sc.nextInt();
      arearec(a,b);
    }
  }