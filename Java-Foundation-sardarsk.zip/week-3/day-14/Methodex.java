import java.util.*;
class Methodex
  {
    public static void studentDetails(int roll,String branch)
    {
      System.out.println("roll number is "+roll);
      System.out.println("branch is "+branch);
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the roll");
      int r=sc.nextInt();
      System.out.println("enter the branch");
      String br=sc.next();
      studentDetails(r,br);
        
    }
  }