import java.util.*;
class Atm
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      do
        {
          System.out.println("select the option to do banking");
          System.out.println("1----for withdrawl"+"\n"+"2----for deposit"+"\n"+"3-----for checkbalance"+"\n"+"4------for exit");
          int num=sc.nextInt();
          if(num=1)
          {
            System.out.println("enter the money you want to withdraw");
            double drawl=sc.nextDouble();
            System.out.println("enter the previous account balance");
            double prev=sc.nextDouble();
            if(prev>=drawl)
            {
              System.out.println("withdrawl is successful")
            }
          }
        }
    }
  }