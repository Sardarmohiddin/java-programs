class Primenums
  {
    public static void main(String args[])
    {
      int i,j,n=20,count;
      for(i=1;i<=n;i++)
        {
          for(j=1;j<=i;j++)
            {
               count=0;
              if(i%j==0
                 {
                System.out.println
                 }
                
            }
          
        }
    }
  }