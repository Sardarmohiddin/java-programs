import java.util.*;
class Descending
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a number n value where you want to print");
      int n=sc.nextInt();
      for(int i=n;i>=1;i--)
        {
        System.out.println("the output is "+i);
        }
    }
  }