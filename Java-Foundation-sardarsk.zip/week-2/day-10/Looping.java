class Looping
  {
    public static void main(String args[])
    {
      int i;
      for(i=1;i<21;i++)
        {
          System.out.println("my name is sardar");
        }
    }
  }