import java.util.*;
class Firstlast
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner (System.in);
      System.out.println("enter a number");
      int num=sc.nextInt();
      int temp=num;
      int last=temp%10;
      int firstdigit;
      while(num>0)
        {
           firstdigit=num%10;
         num= num/10;
        }
      System.out.println("the first digit is:"+firstdigit);
      System.out.println("the last digit is:"+last);
    }
  }