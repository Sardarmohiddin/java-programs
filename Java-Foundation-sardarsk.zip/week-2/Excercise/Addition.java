class Addition
{ 
public static void main(String args[])
{
 int a=50,b=10,c=20; 
int d=a+b+c;
  System.out.println("the addition of three numbers are " +d);
}
}