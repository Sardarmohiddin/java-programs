import java.util.*;
class Factor
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a number");
      int num=sc.nextInt();
      int i=1;
      while(num%i==0)
        {
          
          System.out.println(i);
          i++;
        }
      System.out.println("factors are"+i);
    }
  }