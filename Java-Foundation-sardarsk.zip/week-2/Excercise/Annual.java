import java.util.*;
class Annual
  {
    public static void main(String arges[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the persons month salary");
      double netsal;
      double monthsal=sc.nextDouble();
      double annualsal=12*monthsal;
      if(annualsal<500000)
      {
        System.out.println("no tax is applicable");
      }
      else if((annualsal>500000)&&(annualsal<1000000));
      {
        double tax=((annualsal*15)/100);
        netsal=annualsal-tax;
        System.out.println("the net salary is:"+netsal);
      }
      else if((annualsal>1000000)&&annualsal<1500000));
      {
        double tax=((annualsal*20)/100);
      }
      else if((annualsal>1500000)&&(annualsal<3000000))
        {
         double tax=((annualsal*30)/100);
        }
      else if(annualsal>3000000)
      {
        double tax=((annualsal*50)/100);
      }
      else
      {
        System.out.println("the annual salary is invalid");
      }
           double netsal=(annualsal-tax);
      System.out.println("the net salary of a person is:"+netsal);
    }
  }