class Sample
  {
    public static void main(String args[])
    {
     int a=20,b=10;
      int max=(a>b) ? a : b;
      System.out.println("the greater value is"+max);