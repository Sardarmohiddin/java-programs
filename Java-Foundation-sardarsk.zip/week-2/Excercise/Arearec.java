class Arearec
{ 
public static void main(String args[])
{
 int len=50,bre=10; 
int area=len*bre; 
  System.out.println("area f the rectangle is " +area);
}
}
