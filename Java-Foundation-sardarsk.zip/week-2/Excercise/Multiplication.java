import java.util.*;
class Multiplication
  {
    public static void main(String[] args)
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the table you want ");
      int n=sc.nextInt();
      int res;
      for(int i=1;i<=10;i++)
        {
        res=n*i;
      System.out.println(n+"*"+i+"="+res);
        }
    }
  }
      
        
