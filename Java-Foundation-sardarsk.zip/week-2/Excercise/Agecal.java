import java.util.*;
class Agecal
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the date of birth year of a person");
      int dob=sc.nextInt();
      int present=2023;
      int age=(present-dob);
      System.out.println("the age is:"+age);
      if(age>=18)
      {
        System.out.println("the person is major");
      }
      else
      {
        System.out.println("the person is minor");
      }
      
    }
  }