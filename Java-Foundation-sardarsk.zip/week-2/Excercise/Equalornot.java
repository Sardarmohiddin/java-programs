import java.util.*;

class Equalornot {
  public static void main(String[]args)
    {
      Scanner sc=new Scanner(System.in);
      int a,b;
      System.out.println("Enter the value of a");
      a=sc.nextInt();
      System.out.println("enter the value of b");
      b=sc.nextInt();
      System.out.println("Values of a,b"+a+" "+b);
      System.out.println((a==b));
    }
}