import java.util.*;
class Guessing
  {
    public static void guess (int cmpnum,int usernum)
    {
      do{
        if(cmpnum>usernum)
          System.out.println("the computer num is bigger");
        else 
          System.out.println("the user num is bigger");
      }
      while(cmpnum!=usernum);
        if(cmpnum==usernum)
      {
        System.out.println("the number matches");
      }
    }
   public static void main(String args[])
    {
    System.out.println("this is a game"); 
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the number of computer generated");
      int cmpnum=sc.nextInt();
      System.out.println("enter the number you want from user");
     int  usernum=sc.nextInt();
      guess(cmpnum,usernum);
    }
  }
