class Average
{ 
public static void main(String args[])
{
 int a=50,b=10,c=20; 
float d=(a+b+c)/3f; 
  System.out.println("the average of three numbers are " +d);
}
}