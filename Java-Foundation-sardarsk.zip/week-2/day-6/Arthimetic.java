class Arthimetic
{ 
public static void main(String args[])
{
 int a=50,b=10; 
int c=a+b; 
System.out.println("the addition is:"+c); System.out.println("the substraction is:"+(a-b)); System.out.println("the multiplication is:"+(a*b)); System.out.println("the division is:"+(a/b)); System.out.println("the remainder is:"+(a%b));
 } 
}