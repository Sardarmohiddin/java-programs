class Averagethreenums
  {
    public static void main(String args[])
    {
      int num1=10,num2=20,num3=30;
      float avg=(num1+num2+num3)/3;
      System.out.println("the average is "+avg);
    }
  }