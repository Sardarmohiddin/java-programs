class Bitwiseoperators
  {
    public static void main (String args[])
    {
      int a=10,b=9;
      System.out.println("bitwise and is "+(a&b));
      System.out.println("bitwise or is "+(a|b));
      System.out.println("bitwise xor is "+(a^b));
    }
  }