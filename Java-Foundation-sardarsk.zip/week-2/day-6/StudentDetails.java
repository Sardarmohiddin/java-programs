class StudentDetails
  {
    public static void main(String args[])
    {
      String studentname="sardar mohiddin";
        int rollno=2105114;
       String branch="MCA";
      float percentage=87.5f;
      char grade='A';
      long mobile=6301371334l;
      System.out.println("the student name is " +studentname+"the student roll number is " +rollno+"the student branch is " +branch+"student percentage is " +percentage+"student grade is " +grade+"student contact number is " +mobile);
      
    }
  }