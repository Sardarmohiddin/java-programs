class Logicaloperators
  {
    public static void main(String args[])
    {
      int a=10,b=20,c=30,d=40;
       System.out.println(a<b&&a>c);
       System.out.println(a<b||a>c);
    }
  }