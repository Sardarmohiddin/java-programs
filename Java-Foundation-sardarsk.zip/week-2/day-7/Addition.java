import java.util.Scanner;
class Addition
  {
    public static void main (String args[])
    {
      int a,b;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a value a :");
      a=sc.nextInt();
      System.out.println("enter a value  b :");
      b=sc.nextInt();
      int c=a+b;
      System.out.println("the addition is :"+c);
      
    }
  }