import java.util.Scanner;
class StudentDet
  {
    public static void main(String args[])
    {
     Scanner sc=new Scanner(System.in);
      System.out.println("enter the name of a student :");
    String stuname=sc.next();
System.out.println("Enter student rollno") ;
long rollno=sc.nextLong();
System.out.println("Enter student percentage") ;
float percentage=sc.nextFloat();
System.out.println("student name is :"+stuname);
System.out.println("student roll number :"+rollno);
System.out.println("student percentage :"+percentage);
    }
  }
