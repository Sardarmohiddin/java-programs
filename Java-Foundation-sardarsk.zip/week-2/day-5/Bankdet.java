// bank details of a person
class Bankdet
  {
    public static void main(String args[])
    {
      String name="sardar mohiddin";
      long accnum=0000000000000001234l;
      float accbal =18000f;
      String  Ifsc="SBI10000000";
      System.out.println("my name is "+ name);
      System.out.println("my account number is  "+ accnum);
      System.out.println("my account balance is  "+accbal);
      System.out.println(" bank ifsc code is " + Ifsc);
    }
  }