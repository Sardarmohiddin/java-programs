class Details
  {
    public static void main(String args[])
    {
      String name="sardar";
      long phonenum=6301371334l;
      float percentage=87.5f;
      String  address="vijayawada";
      char grade='a';
      boolean martialstatus=false;
      System.out.println("my name is "+ name);
      System.out.println("my phone num is "+ phonenum);
      System.out.println("my percentage  "+percentage);
      System.out.println("my address is  "+ address);
      System.out.println(" my grade  " + grade);
      System.out.println(martialstatus);
    }
  }