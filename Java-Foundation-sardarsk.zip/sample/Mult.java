import java.util.*;
class Mult
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the table you want");
      int n=sc.nextInt();
      for(int i=0;i<21;i++)
        {
          System.out.println(n+"*"+i+"="+n*i);
        }
    }
  }