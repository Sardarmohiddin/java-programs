// voting eligibility criteria of a person
import java.util.Scanner;
class Vote
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in)
        int person=sc.nextInt()
        if(person>=18)
        System.out.println("the person is eligible for vote");
      else
        System.out.println("the person is not eligible");
    }
  }
