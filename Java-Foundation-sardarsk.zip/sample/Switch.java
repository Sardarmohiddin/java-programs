import java.util.*;
class Switch
  {
    public static void main(String args[])
    {
      System.out.println("enter the user 1 value");
      Scanner sc=new Scanner(System.in);
      int user1=sc.nextInt();
      System.out.println("enter the user 2 value");
      int user2=sc.nextInt();
      System.out.println("enter the user 3 value");
      int user3=sc.nextInt();
      System.out.println("enter the user 4 value");
      int user4=sc.nextInt();
      if((user1==user2)&&(user1==user3)&&(user1==user4))
         System.out.println("the numbers are equal");
      else 
        System.out.println("the numbers are not equal");
    }
  }