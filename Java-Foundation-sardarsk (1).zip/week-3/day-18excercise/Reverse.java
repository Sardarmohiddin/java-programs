import java.util.*;
class Reverse
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the string values");
      String s=sc.nextLine();
      String rev="";
      char ch;
      for(int i=0;i<s.length();i++)
        {
          ch=s.charAt(i);
          rev=ch+rev;
        }   
      System.out.println("the reverse of astring is "+rev);
    }
    
  }