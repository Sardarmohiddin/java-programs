import java.util.*;
class Palindrome
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the string values");
      String s=sc.nextLine();
      String rev="";
      String temp=s;
      char ch;
      for(int i=0;i<s.length();i++)
        {
          ch=s.charAt(i);
          rev=ch+rev;
        }  
      System.out.println("the reverse of a string is "+rev);
      if(temp.equals(rev))
        System.out.println("the string is palindrome");
      else
        System.out.println("the string is not palindrome");
    }
  }