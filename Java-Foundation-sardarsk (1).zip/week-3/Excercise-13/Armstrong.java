import java.util.*;
class Armstrong
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a number");
      int num=sc.nextInt();
      int temp,cmp,result;
       num=temp;
       num=cmp;
      int count;
      while(num>0)
        {
         num=num/10;
          count=count+1;
         }
          System.out.println(count);
        int power=count;
      while(temp>0)
        {
          int digit=temp%10;
          for(int i=1;i<=power;i++)
          {
           result=result*digit;
          }
          temp=temp/10;
        }
      System.out.println(result);
    if(result==cmp)
    {
      System.out.println("it is a strong number");
    }
      else
      {
        System.out.println("it is not a strong number");
      }
    }
  }