import java.util.*;
class Even
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the starting number");
      int a=sc.nextInt();
      System.out.println("enter the last number upto u want the even numbers");
      int b=sc.nextInt();
      for(int i=a;i<=b;i++)
        {
          if(i%2==0)
          {
            System.out.println("the even no is:"+i);
          }
          else
          {
            System.out.println(i+"is odd number");
          }
        }
    }
  }