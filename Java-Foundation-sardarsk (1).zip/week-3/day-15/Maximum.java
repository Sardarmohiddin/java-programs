import java.util.*;
class Maximum
  {
    public static void main(String args[])
    {
      
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the size of an array");
      int size=sc.nextInt();
      int a[]=new int[size];
      System.out.println("enter the elements of an array");
      for(int i=0;i<size;i++)
        {
          a[i]=sc.nextInt();
        }
      int max=a[0];
      for(int i=0;i<size;i++)
        {
        
          if(max<a[i])
          {
            max=a[i];
          }
        
        }
      System.out.println("the max value is"+max);
    }
  }