import java.util.*;
class EvenforMet
  {
    public static void meth(int m,int n)
    {
      for(int i=m;i<=n;i++)
        {
          if(i%2==0)
          {
            System.out.println(i);
          }
        }
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the first number");
      int m=sc.nextInt();
      System.out.println("enter the second number");
      int n=sc.nextInt();
      meth(m,n);
    }
  }