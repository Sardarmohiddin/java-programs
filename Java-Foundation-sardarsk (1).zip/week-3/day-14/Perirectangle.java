import java.util.*;
class Perirectangle
  {
    public static void perimeter(int l,int b)
    {
      int peri=2*(l+b);
      System.out.println("the perimeter of a rectangle is"+peri);
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the len");
      int len=sc.nextInt();
      System.out.println("enter the breadth");
      int bre=sc.nextInt();
      perimeter(len,bre);
      perimeter(4,3);
      perimeter(len,5);
      
    }
  }