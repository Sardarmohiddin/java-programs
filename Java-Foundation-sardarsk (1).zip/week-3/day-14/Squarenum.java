import java.util.*;
class Squarenum
  {
    public static void Squarearea(int side)
    {
     int area=side*side;
      System.out.println("the area of a square is"+area);
    }
    public static void SquarePerimeter(int side)
    {
      int perimeter=4*side;
      System.out.println("the perimeter of a square is"+perimeter);
    }
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      int side=sc.nextInt();
      Squarearea(5);
      SquarePerimeter(7);
      SquarePerimeter(side);
    }
      
      
    }
  