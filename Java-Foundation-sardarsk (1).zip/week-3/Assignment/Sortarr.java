import java.util.Scanner;
class Sortarr
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the size of an array");
      int size=sc.nextInt();
      int sardar[]=new int[size];
        int temp=0;
        System.out.println("enter the elements into the array");
      for(int i=0;i<size;i++)
        {
          sardar[i]=sc.nextInt(); 
        }
      System.out.println("the sorted elements are");
      for(int i=0;i<size;i++)
        for(int j=i+1;j<size;j++)
          {
            if(sardar[i]>sardar[j])
            {
              temp=sardar[i];
              sardar[i]=sardar[j];
              sardar[j]=temp;
            }
          }
            for(int i=0;i<size;i++)
      System.out.println(sardar[i]);
    }
  }
  