class Examples
  {
    public static void main(String args[])
    {
      int x=5;
      do
        {
          System.out.println("it is five");
          x++;
        }
        while(x<10);
    }
  }