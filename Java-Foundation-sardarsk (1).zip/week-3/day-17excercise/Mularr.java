import java.util.*;

class Mularr {
  public static void main(String args[]) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter the row of an array");
    int row = sc.nextInt();
    System.out.println("enter the column of an array");
    int col = sc.nextInt();
    int a[][] = new int[row][col];
    System.out.println("enter the values into array1");
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++)
        a[i][j] = sc.nextInt();
    }
    int b[][] = new int[row][col];
    System.out.println("enter the values into array2");
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++)
        b[i][j] = sc.nextInt();
    }
    int c[][] = new int[row][col];
    multiply(a, b, c, row, col);
  }

  public static void multiply(int a[][], int b[][], int c[][], int row, int col) {
    int i, j;
    for (i = 0; i < c.length; i++) {
      for (j = 0; j < c.length; j++)
        c[i][j] = a[i][j] * b[i][j];

    }
    for (i = 0; i < c.length; i++) {
      for (j = 0; j < c.length; j++) {
        System.out.print(c[i][j] + " ");
      }
      System.out.println();
    }
  }
}