import java.util.*;
class Rightrotation
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      int arr[]={10,20,30,40,50};
      System.out.println("the array before right rotation is");
  for(int i=0;i<arr.length;i++)
    {
     System.out.println(arr[i]); 
    }
      int temp=arr[arr.length-1];
      for(int i=0;i<arr.length;i++)
        {
          arr[i+1]=arr[i];
          arr[arr.length-1]=arr[arr.length];
          break;
        }
      arr[0]=temp;
      System.out.println("the array after right rotation is");
      for(int i=0;i<arr.length;i++)
        {
          System.out.println(arr[i]);
        }
    }
  }