class Trim
  {
    public static void main(String args[])
    {
      String s="  sardar  ";
      System.out.println(s);
      System.out.println(s.trim());
    }
  }