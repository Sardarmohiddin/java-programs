
   /*WAP to find length of a string and compare and concatenate two strings.*/
class Sample
  {
public static void main(String args[])
    {
      String s="sardar";
      String m="mohiddin";
      boolean b=s.equals(m);
      System.out.println(b);
      int c=s.length();
      System.out.println(c);
      String l=s.concat(m);
      System.out.println(l);
      
    }
  }
    
  