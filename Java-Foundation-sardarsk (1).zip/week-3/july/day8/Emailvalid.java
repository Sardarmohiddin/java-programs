import java.util.*;
class Emailvalid
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      String s=sc.nextLine();
      System.err.println("enter the email");
      if(s.contains("@")&&s.contains(".")&&s.endsWith(".com")||s.endsWith(".org"))
      {
        System.out.println("email is valid");
      }
      else
        System.out.println("not a valid email");
    }
  }