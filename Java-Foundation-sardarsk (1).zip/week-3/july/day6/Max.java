import java.util.*;
class Max
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      int arr[]=new int [5];
      System.out.println("enter the size of an array");
      int size=sc.nextInt();
      int max=arr[0];
      for (int i=0;i<arr.length;i++)
        arr[i]=new sc.nextInt();
      for(int i=0;i<arr.length;i++)
        {
          if(max<arr[i])
            max=arr[i];
        }
      System.out.println("the max element in array is"+max);
    }
    
  }