import java.util.*;
class Array
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      int arr[]=new int[10];
      System.out.println("enter the elements into the array");
      for(int i=0;i<arr.length;i++)
        {
          arr[i]=sc.nextInt();
        }
      System.out.println("the printed elements of an array are");
      for(int i=0;i<arr.length;i++)
        {
          System.out.println(arr[i]);
        }
    }
  }