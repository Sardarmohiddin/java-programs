import java.util.*;
class Basketball
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the sets of the game to be played");
      int size=sc.nextInt();
      System.out.println("enter the TEAM scores");
      int Team[]=new int[size];
      for(int i=0;i<size;i++)
        Team[i]=sc.nextInt();
      System.out.println("enter the Opposing team scores");
      int Opp[]=new int[size];
      for(int i=0;i<size;i++)
        Opp[i]=sc.nextInt();
      int temp[]=new int[size];
      for(int i=0;i<size;i++)
        {
          temp[i]=((Team[i]+Opp[i])/2*size);
          System.out.println("the average score of both teams are");
          for(int i=0;i<size;i++)
        }
    }
  }