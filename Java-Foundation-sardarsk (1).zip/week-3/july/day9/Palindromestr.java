//to check the largest palindrome in a string
import java.util.*;
class Palindromestr
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a string");
      String s=sc.nextLine();
      String str[]=s.split(" ");
      int len=0;
      for(int i=0;i<str.length;i++)
        {
          String temp=str[i];
          String rev="";
        }
      for(int j=str.length-1;j>=0;j--)
        {
          rev=rev+charAt(j);
        }
      if(temp.equals(rev))
      {
        System.out.println(temp);
      }
    }
  }