//to claculate the frequency of a given string
import java.util.*;
class Frequencystr
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the string");
      String str=sc.nextLine();
      boolean b[]=new boolean[str.length];
      for(int k=0;k<str.length;k++)
      
    }
  }