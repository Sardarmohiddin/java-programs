import java.util.*;
class Frequency
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the size of an array");
      int size=sc.nextInt();
      int arr[]=new int[size];
      System.out.println("enter the array elements");
      for(int i=0;i<size;i++)
        {
          arr[i]=sc.nextInt();
        }
      boolean b[]=new boolean[size];
      for(int k=0;k<size;k++)
        {
          b[k]=false;
        }
      for(int i=0;i<size;i++)
        {
          int count=1;
          for(int j=i+1;j<size;j++)
            {
              if(arr[i]==arr[j])
              {
                count++;
                b[j]=true;
              }
            }
          System.out.println("the frequency of "+arr[i]+"---------------->"+count);
        }
        
    }
  }