
import java.util.*;
class Cases
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the number");
      int monthnum=sc.nextInt();
      switch(monthnum)
        {
          case 1:
            System.out.println("jnuary month having 31 days");
            break;
          case 2:
            System.out.println("feb month having 29 days");
            break;
          case 3:
            System.out.println("march have 31 days");
            break;
          case 4:
            System.out.println("april have 30 days");
            break;
          case 5:
            System.out.println("may have 31 days");
            break;
          case 6:
            System.out.println("june have 30 days");
            break;
          case 7:
            System.out.println("july have 31 days");
            break;
          case 8:
            System.out.println("august have 31 days");
            break;
          case 9:
            System.out.println("sep have 30 days");
            break;
          case 10:
            System.out.println("oct have 31 days ");
            break;
          case 11:
            System.out.println("nov have 30 days");
            break;
          case 12:
            System.out.println("dec have 31 days");
            break;
          default:
            System.out.println("entered number is invalid");
            break;
        }
    }
  }