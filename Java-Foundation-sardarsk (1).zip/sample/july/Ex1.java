class Ex1
  {
    public static void main(String args[])
    {
      double l,b;
      l=5.6;
      b=8.5;
      double area=l*b;
      System.out.println("the area of a rectangle is"+area);
      double peri=2*(l+b);
      System.out.println("perimetr of arectangle is "+peri);
    }
  }