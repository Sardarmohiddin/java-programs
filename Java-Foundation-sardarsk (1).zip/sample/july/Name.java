import java.util.*;
class Name
  {
    public static void main(String args[])
    {
      System.out.println("enter the name");
     Scanner sc=new Scanner(System.in);
       String name=sc.nextLine();
      String s1="sardar";
      String s2="yasin";
      String s3="abdul";
      String s4="sajid";
      if(s1.equals(name))
        System.out.println("the name is found");
      else if(s2.equals(name))
        System.out.println("the name is found");
      else if(s3.equals(name))
             System.out.println("the name is found");
        else if(s4.equals(name))
          System.out.println("the name is found");
      else
          System.out.println("invalid name,not found in list");
    }
  }