import java.util.*;
class Nested
  {
    public static void main(String args[])
    {
      System.out.println("enter the country");
      Scanner sc=new Scanner(System.in);
    String place=sc.nextLine();
      if(place.equals("India"))
      {
          int age=30;
        if(age>=18)
          System.out.println("eligible to vote");
        
          
      }
      else
        System.out.println("not eligible to vote");
    }
  }