import java.util.*;
class Cube
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the number upto which u want cube");
      int n=sc.nextInt();
      for(int i=1;i<=n;i++)
        System.out.println("the cube of  " +i +"are :" 
 +i*i*i);
    }
  }
  