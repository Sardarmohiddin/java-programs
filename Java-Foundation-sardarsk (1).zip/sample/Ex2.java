class Ex2
  {
    public static void main(String args[])
    {
      int a,b,c;
      a=10;
      b=15;
      c=a+b;
      if(c>20)
        System.out.println("the sum is considered"+c);
    }
  }