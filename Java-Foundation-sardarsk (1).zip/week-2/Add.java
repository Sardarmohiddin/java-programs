class Add
  {
    public static void main(String args[])
    {
      int a,b,c,d,e;
      a=10;
      b=20;
      c=30;
      d=40;
      e=50;
      System.out.println("the sum of numbers is"+(a+b+c+d+e));
      System.out.println("average og the numbers are"+((a+b+c+d+e)/5));
    }
  }