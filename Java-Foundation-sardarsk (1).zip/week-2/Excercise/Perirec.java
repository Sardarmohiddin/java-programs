class Perirec
{ 
public static void main(String args[])
{
 float len=55.5f,bre=10.0f; 
float perimeter=2*(len+bre); 
  System.out.println("perimeter of the rectangle is " +perimeter);
}
}