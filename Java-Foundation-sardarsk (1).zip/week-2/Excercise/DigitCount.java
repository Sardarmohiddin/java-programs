
import java.util.*;
class DigitCount
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the number");
      int num=sc.nextInt();
      int count=0;
      while(num>0)
        {
           num/=10;
          count=count+1;
        }
      System.out.println("the no of digits in a numbers is: "+count);
    }
  }