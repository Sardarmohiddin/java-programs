import java.util.*;
class Fibonacci
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a number upto u want the series");
      int num=sc.nextInt();
      int first=0,second=1;
      System.out.print(first);
      System.out.print(second);
       int third;
      for(int i=1;i<=num;i++)
        {
          third=first+second;
          System.out.print(third);
          first=second;
          second=third;
        }
    }
  }