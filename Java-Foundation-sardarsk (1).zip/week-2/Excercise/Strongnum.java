import java.util.*;
class Strongnum
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter a number");
      int num=sc.nextInt();
      int temp=0;
      num=temp;
      int digit;
      int fact=1;
      int sum=0;
      while(num>0)
        {
           digit=num%10;
          num=num/10;
          for(int i=1;i<=digit;i++)
            {
            fact=fact*i;
            }
         sum=sum+fact;
          
        }
    System.out.println(sum);
      if(temp==sum)
      {
        System.out.println("the number is strong");
      }
      else{
        System.out.println("the number is not a strong number");
      }
    }
  }