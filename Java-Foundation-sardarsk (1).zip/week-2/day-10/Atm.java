import java.util.*;
class Atm
  {
    
  }