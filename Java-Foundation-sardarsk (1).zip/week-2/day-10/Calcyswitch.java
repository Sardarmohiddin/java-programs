import java.util.*;
class Calcyswitch
  {
    public static void main(String []args)
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the value of a");
      double a,b,c;
      a=sc.nextDouble();
      System.out.println("enter the value of b");
      b=sc.nextDouble();
System.out.println("enter the operator you want to perform");
      char ch=sc.next().charAt(0);
      switch(ch)
        {
        case '/':
            System.out.println("division will perform");
            c=a/b;
            System.out.println("the result is"+c);
            break;
          case '*':
            System.out.println("multipication will perform");
            c=a*b;
            System.out.println("the result is"+c);
            break;
          case '+':
            
            System.out.println("add is performed");
            c=a+b;
            System.out.println("the result is"+c);
            break;
          case '_':
            System.out.println("sub is performed");
            c=a-b;
            System.out.println("the result is"+c);
            break;
          default :
            System.out.println("the entered operator is invalid");
        }
              
            
    }
  }