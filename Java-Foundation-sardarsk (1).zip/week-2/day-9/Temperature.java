import java.util.*;
class Temperature
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the format for which you want to convert");
      System.out.println("enter c that is celcius or enter f that is farenheit ");
      char ch=sc.next().charAt(0);
      if((ch=='f')||(ch=='F'))
      {
        System.out.println("enter the temparature in celcius:");
        double celcius=sc.nextDouble();
        double faren=((1.8*celcius)+32);
        System.out.println("the converted temperature in farenheit is:"+faren);
        
      }
      else if((ch=='c')||(ch='C'))
      {
       System.out.println("enter the temperature in farenheit:");
        double faren=sc.nextDouble();
        double celcius=0.55*(faren-32);
        System.out.println("the converted temperature in celcius is:"+celcius);
      }
      else
      {
        System.out.println("it is an invalid format");
      }
    }
  }