import java.util.*;
class Grading
  {
    public static void main (String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the artimetic marks:");
    int art=sc.nextInt();
      System.out.println("enter the reasoning marks:");
      int rea=sc.nextInt();
    System.out.println("enter the english marks:");
      int eng=sc.nextInt();
      double total=(art+rea+eng);
      double percentage=(total/300)*100;
      if(percentage>=50&&percentage<70)
        {
        System.out.println("the grade is c");
      }
      else if((percentage>=70)&&(percentage<85))
      {
      System.out.println("the grade is b");
      }
      else if((percentage>=85)&&(percentage<=100))
      {
      System.out.println("the grade is a");
      }
      else 
      {
        System.out.println("entered marks or invalid");
      }
    }
  }
  