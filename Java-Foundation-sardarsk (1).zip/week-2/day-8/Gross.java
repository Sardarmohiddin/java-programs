import java.util.*;
class Gross
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the basic salary:");
float basicsal=sc.nextFloat();
      if(basicsal<=10000)
      {
        float hra=(basicsal*2)/10;
        float da=(basicsal*8)/10;
        float grosssalary=(basicsal+hra+da);
        System.out.println("the gross salary is "+grosssalary);
      }
      else if(basicsal<=20000)
      {
        float hra=(basicsal*4)/10;
        float da=(basicsal*9)/10;
        float grosssalary=(basicsal+hra+da);
        System.out.println("the gross salary is "+grosssalary);
      }
      else if(basicsal>=20000)
      {
       float hra=(basicsal*3)/10;
        float da=(basicsal*19)/20;
        float grosssalary=(basicsal+hra+da);
        System.out.println("the gross salary is "+grosssalary); 
      }
      else 
      {
        System.out.println("the entered salary is invalid");
      }
    }
  }
        
 
        
